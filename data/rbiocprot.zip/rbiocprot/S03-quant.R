library(MSnbase)

data("itraqdata")
plot(itraqdata[[25]], 
     full = TRUE, 
     reporters = iTRAQ4)


data(msnset)
dim(msnset)
## expression data
exprs(msnset)[1:10, 1:2]
sampleNames(msnset)
featureNames(msnset)

## feature meta-data
class(fData(msnset))
dim(fData(msnset))
fvarLabels(msnset)

## sample meta-data
pData(msnset)
msnset$group <- c("A", "A",
                  "B", "B")
pData(msnset)

## Creating MSnSet from raw data
## (see ?quantify)

## Creating MSnSet from 
## third-party software

BiocManager::install("pRolocdata")
csvfile <- 
  dir(system.file("extdata", 
            package = "pRolocdata"),
    pattern = "ms3-rep12", 
    full.names = TRUE)
basename(csvfile)

## View(read.csv(csvfile)[1:100, ])
getEcols(csvfile, split = ",", n = 2)

msn <- 
  readMSnSet2(csvfile, 
              ecol = 8:27,
              fnames = 1,
              skip = 1)
msn
sampleNames(msn)
head(featureNames(msn))
fvarLabels(msn)
fData(msn)

pData(msn)
dim(msn)
pData(msn)$batch <- 
  rep(1:2, each = 10)
pData(msn)$group <- 
  rep(rep(c("CTRL", "COND"), 
            each = 5),
          2)
pData(msn)

featureNames(msn)


f <- msdata::quant(full.names = TRUE)
f

getEcols(f, split = "\t")

i <- grepEcols(f, 
          "Intensity ",
          split = "\t")

cptac <- 
  readMSnSet2(f, ecol = i,
              sep = "\t")
cptac
fvarLabels(cptac)

featureNames(cptac) <- 
  fData(cptac)$Sequence
cptac

sampleNames(cptac) <- 
  sub("Intensity\\.",
      "",
      sampleNames(cptac))
sampleNames(cptac)

pData(cptac)$condition <- 
  rep(c("A", "B"),
      each = 3)
pData(cptac)$sample <- 
  rep(7:9, 2)
pData(cptac)

sub("_.+", 
    "", 
    sampleNames(cptac))

sub("^.+_", 
    "", 
    sampleNames(cptac))

cptac <- 
  selectFeatureData(cptac,
                  fcol = c(
                    "Proteins",
                    "Potential.contaminant",
                    "Reverse",
                    "Sequence"))

fvarLabels(cptac)

exprs(cptac)[1:10, ]

## BiocManager::install("statOmics/MSqRob")

## HERE

keep <- MSqRob::smallestUniqueGroups(
            fData(cptac)$Proteins)
head(keep)
