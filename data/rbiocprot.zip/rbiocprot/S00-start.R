install.packages("BiocManager")
BiocManager::install("MSnID")


BiocManager::install("rpx")
## ProteomeXchange
library("rpx")

px1 <- PXDataset("PXD000001")
px1
pxfiles(px1)

pxtax(px1)
pxurl(px1)
pxref(px1)


pxget(px1, 6)

BiocManager::install("msdata")
## Data package
library("msdata")

proteomics()
ident()
quant()


quant(full.names = TRUE)


library(AnnotationHub)
ah <- AnnotationHub()
ah
query(ah, "proteomics")
